package com.tecvinson.location;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
