package com.tecvinson.location.configs;

import com.tecvinson.location.entities.Tenant;
import com.tecvinson.location.repositories.TenantRepository;
import com.tecvinson.location.services.ValidationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.UUID;

@Configuration
public class DataLoader {

    private static final Logger logger = LoggerFactory.getLogger(DataLoader.class);

    private final ValidationService validationService;

    // Inject ValidationService
    public DataLoader(ValidationService validationService) {
        this.validationService = validationService;
    }

    @Bean
    public CommandLineRunner loadInitialData(TenantRepository tenantRepository) {
        return args -> {
            if (!tenantRepository.findByEmail("admin@example.com").isPresent()) {
                String apiKey = UUID.randomUUID().toString();  // Generate API key
                String hashedApiKey = validationService.hashApiKey(apiKey); // Hash the API key

                Tenant admin = new Tenant();
                admin.setName("Admin");
                admin.setApiKey(hashedApiKey);  // Store the hashed API key
                admin.setEmail("admin@example.com");
                admin.setActive(true);
                admin.setCreatedBy("System");
                admin.setModifiedBy("System");

                tenantRepository.save(admin);

                // Write the original API key to a file (for later use in development)
                try {
                    Files.write(Paths.get("admin-api-key.txt"), apiKey.getBytes(), StandardOpenOption.CREATE);
                    logger.info("Admin tenant created. API key written to admin-api-key.txt");
                } catch (IOException e) {
                    logger.error("Failed to write API key to file", e);
                }
            } else {
                logger.info("Admin tenant already exists.");
            }
        };
    }
}
