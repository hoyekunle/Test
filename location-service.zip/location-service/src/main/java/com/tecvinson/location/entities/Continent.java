package com.tecvinson.location.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "Continents")
public class Continent extends CommonFields {

    @Column(nullable = false,unique = true)
    private String name;

    @ManyToOne()
    @JoinColumn(name = "client_id")
    private Client client;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
}
