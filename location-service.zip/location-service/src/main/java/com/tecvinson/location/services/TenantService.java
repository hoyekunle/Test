package com.tecvinson.location.services;

import com.tecvinson.location.dtos.tenant.CreateTenantRequest;
import com.tecvinson.location.dtos.tenant.TenantResponse;
import com.tecvinson.location.dtos.tenant.UpdateTenantRequest;
import com.tecvinson.location.entities.Tenant;
import com.tecvinson.location.exceptions.NotFoundException;
import com.tecvinson.location.repositories.TenantRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class TenantService {

    // Logger instance for tracking activities in the service
    private static final Logger logger = LoggerFactory.getLogger(TenantService.class);

    private final TenantRepository tenantRepository; // Repository for database operations
    private final ModelMapper modelMapper; // Used for mapping between DTOs and entities
    private final ValidationService validationService;

    // Constructor-based dependency injection for the repository and model mapper
    public TenantService(TenantRepository tenantRepository, ModelMapper modelMapper, ValidationService validationService) {
        this.tenantRepository = tenantRepository;
        this.modelMapper = modelMapper;
        this.validationService = validationService;
    }

    /**
     * Creates a new tenant in the system.
     * @param tenantRequest Data required to create a new tenant (from the DTO).
     * @return The response containing the created tenant's information.
     */
    @Transactional
    public TenantResponse createTenant(CreateTenantRequest tenantRequest) {
        logger.info("Creating a tenant");

        // Check if Email is Valid
        validationService.validateEmail(tenantRequest.getEmail());

        // Generate a unique API key for the tenant
        String generatedApiKey = UUID.randomUUID().toString();

        // Hash the generated API key before storing it
        String hashedApiKey = validationService.hashApiKey(generatedApiKey);

        // Sanitize the tenant name to use as the file name
        String sanitizedFileName = sanitizeFileName(tenantRequest.getName()) + "-ApiKey.txt";

        // Write the generated API key to a file with the sanitized tenant name
        try {
            Files.write(Paths.get(sanitizedFileName), generatedApiKey.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            logger.info("API key written to file: {}", sanitizedFileName);
        } catch (IOException e) {
            logger.error("Failed to write API key to file", e);
        }

        // Map the incoming DTO to a Tenant entity
        Tenant tenant = modelMapper.map(tenantRequest, Tenant.class);
        tenant.setApiKey(hashedApiKey);
        tenant.setActive(true);
        tenant.setCreatedBy("SYSTEM");
        tenant.setModifiedBy("SYSTEM");

        // Save the tenant in the database
        tenant = tenantRepository.save(tenant);

        logger.info("Tenant with ID: {} created", tenant.getId());

        // Map the saved entity back to a response DTO
        TenantResponse tenantResponse = modelMapper.map(tenant, TenantResponse.class);
        tenantResponse.setApiKey(generatedApiKey);
        return tenantResponse;
    }




    /**
     * Updates an existing tenant's information.
     * @param id The ID of the tenant to be updated.
     * @param tenantRequest Data required to update the tenant (from the DTO).
     * @return The updated tenant's information as a response DTO.
     */
    @Transactional
    public TenantResponse updateTenant(UUID id, UpdateTenantRequest tenantRequest) {
        logger.info("Updating tenant with ID: {}", id);

        // Find the tenant by ID or throw an exception if not found
        Tenant tenant = tenantRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Tenant not found"));

        //Check if Email is Valid
        validationService.validateEmail(tenantRequest.getEmail());

        // Update tenant fields with data from the request DTO
        tenant.setEmail(tenantRequest.getEmail());
        tenant.setActive(tenantRequest.isActive());
        tenant.setCreatedBy("SYSTEM");
        tenant.setModifiedBy("SYSTEM");

        logger.info("Tenant updated. Email: {}, Status: {}", tenantRequest.getEmail(), tenantRequest.isActive());

        // Save the updated tenant and map it to a response DTO
        return modelMapper.map(tenantRepository.save(tenant), TenantResponse.class);
    }

    /**
     * Retrieves all tenants in the system.
     * @return A list of tenant response DTOs.
     */
    public List<TenantResponse> getTenants() {
        logger.info("Retrieving all tenants");

        // Retrieve all tenants from the database
        List<Tenant> tenants = tenantRepository.findAll();
        if (tenants.isEmpty()) {
            logger.warn("No tenants found in the database");
            return Collections.emptyList();
        } else {
            logger.info("Found {} tenants", tenants.size());
        }

        // Map the list of tenants to a list of response DTOs
        return tenants.stream()
                .map(tenant -> modelMapper.map(tenant, TenantResponse.class))
                .collect(Collectors.toList());
    }

    /**
     * Retrieves a specific tenant by ID.
     * @param id The ID of the tenant to retrieve.
     * @return The tenant's information as a response DTO.
     */
    public TenantResponse getTenant(UUID id) {
        logger.info("Retrieving tenant with ID: {}", id);

        // Find the tenant by ID or throw an exception if not found
        Tenant tenant = tenantRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Tenant not found"));

        // Map the tenant entity to a response DTO
        return modelMapper.map(tenant, TenantResponse.class);
    }

    public String sanitizeFileName(String tenantName) {
        // Replace spaces with underscores
        String sanitized = tenantName.replaceAll("\\s+", "_");

        // Remove characters that are not allowed in file names
        sanitized = sanitized.replaceAll("[^a-zA-Z0-9_-]", "");

        // Optionally, trim to a reasonable length (e.g., 50 characters)
        if (sanitized.length() > 50) {
            sanitized = sanitized.substring(0, 50);
        }

        return sanitized;
    }

}
